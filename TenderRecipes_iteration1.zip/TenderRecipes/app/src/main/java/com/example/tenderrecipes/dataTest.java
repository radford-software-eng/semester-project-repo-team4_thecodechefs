package com.example.tenderrecipes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class dataTest extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference dataRef;

    Button test;
    TextView name;
    TextView diff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        database = FirebaseDatabase.getInstance();
        dataRef = database.getReference("TenderRecipes");

        test = findViewById(R.id.testB);
        name = findViewById(R.id.nameT);
        diff = findViewById(R.id.diffT);

        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                test();
            }
        });

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_test);
    }

    public void test(){



    }
}
