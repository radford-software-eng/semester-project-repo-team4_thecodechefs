package com.example.tenderrecipes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class AccountPage extends AppCompatActivity {

    TextView userT;
    TextView passT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_page2);

        userT = findViewById(R.id.usernameT);
        passT = findViewById(R.id.passwordT);

        Intent i = getIntent();

        Account account = i.getParcelableExtra("account");

        Toast.makeText(AccountPage.this, account.getUsername(), Toast.LENGTH_SHORT).show();

        userT.setText(""+account.getUsername());
        passT.setText(""+account.getPassword());


    }
}
