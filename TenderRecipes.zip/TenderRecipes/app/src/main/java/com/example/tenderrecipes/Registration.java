package com.example.tenderrecipes;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Registration extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button submit;
    private Button back;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);

        username = findViewById(R.id.userField);
        password = findViewById(R.id.pwField);
        submit = findViewById(R.id.submitButton);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent intent = new Intent(Registration.this, LogIn.class);
                startActivity(intent);
            }
        });
    }
}
