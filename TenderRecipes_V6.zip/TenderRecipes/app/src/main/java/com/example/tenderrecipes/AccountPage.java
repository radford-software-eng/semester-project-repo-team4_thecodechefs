package com.example.tenderrecipes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AccountPage extends AppCompatActivity {

    TextView userT;
    ImageView upArrow;
    LinearLayout recipeListLayout;
    ScrollView recipeScroll;

    FirebaseDatabase database;
    DatabaseReference recipeDataRef;

    ArrayList<Integer> savedRecipes;

    Intent detailIntent;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_page);

        userT = findViewById(R.id.usernameT);
        recipeListLayout = findViewById(R.id.recipeList);
        recipeScroll = findViewById(R.id.recipeScroll);
        upArrow = findViewById(R.id.upArrow);

        database = FirebaseDatabase.getInstance();
        recipeDataRef = database.getReference("Recipes");

        detailIntent = new Intent(AccountPage.this, RecipeDetail.class);

        Intent intent = getIntent();
        final Account account = intent.getParcelableExtra("account");

        savedRecipes = intent.getIntegerArrayListExtra("accList");

        userT.setText("Welcome "+account.getUsername());

        upArrow.setOnTouchListener(new OnSwipeTouchListener(AccountPage.this){
            public void onSwipeTop() {
                Toast.makeText(getApplicationContext(), "Swipe up", Toast.LENGTH_SHORT).show();
                finish();
            }

        });

        if(!savedRecipes.isEmpty()){

            recipeDataRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    for(int i = 0; i < savedRecipes.size(); i++){
                        for(DataSnapshot recipeSnapshot : dataSnapshot.getChildren()){
                            final Recipe re = recipeSnapshot.getValue(Recipe.class);
                            if(re.getTempC() == savedRecipes.get(i)){
                                final CardView recipeCard = new CardView(getApplicationContext());
                                final TextView nameText = new TextView(getApplicationContext());
                                final TextView diff = new TextView(getApplicationContext());
                                final ImageView img = new ImageView(getApplicationContext());

                                nameText.setText(re.getName());
                                nameText.setPadding(0,90,0,0);
                                nameText.setTypeface(null, Typeface.BOLD);
                                nameText.setTextColor(Color.BLACK);

                                /*diff.setText(re.getDifficulty());
                                diff.setPadding(1250, 90, 0, 0);
                                diff.setTypeface(null, Typeface.BOLD);
                                diff.setTextColor(Color.BLACK);*/

                                img.setImageResource(AccountPage.this.getResources().getIdentifier(re.getImgName(),
                                        "drawable", AccountPage.this.getPackageName()));
                                img.setScaleType(ImageView.ScaleType.CENTER_CROP);

                                recipeCard.addView(img);
                                recipeCard.addView(nameText);
                                recipeCard.addView(diff);
                                recipeCard.setClickable(true);

                                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 150);
                                LinearLayout.LayoutParams spacePar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 20);
                                recipeCard.setLayoutParams(params);
                                Space space = new Space(getApplicationContext());
                                space.setLayoutParams(spacePar);

                                recipeListLayout.addView(recipeCard);
                                recipeListLayout.addView(space);

                                recipeCard.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        detailIntent.putExtra("recipeNum", re.getTempC());
                                        startActivity(detailIntent);
                                        //Intent
                                        /*Log.d("myTag", ""+re.getName());
                                        LinearLayout.LayoutParams expParam =
                                                new LinearLayout.LayoutParams(1325, 2000);
                                        expParam.setMargins(50,0,0,0);
                                        TextView ingT = new TextView(getApplicationContext());
                                        TextView instT = new TextView(getApplicationContext());
                                        LinearLayout.LayoutParams insParam =
                                                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 500);
                                        ingT.setLayoutParams(insParam);
                                        instT.setLayoutParams(insParam);

                                        nameText.setPadding(0,900,0,0);
                                        diff.setPadding(1150,900,0,0);

                                        ingT.setPadding(0,0,0,0);
                                        instT.setPadding(0,800,0,0);

                                        img.setScaleType(ImageView.ScaleType.FIT_END);

                                        ingT.setText("THIS IS A TEST THIS IS A TEST THIS IS A TEST\nTHIS IS A TESTTHIS IS A TESTTHIS IS A TEST\nTHIS IS A TESTTHIS IS A TESTTHIS IS A TEST");
                                        instT.setText("WOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWO\nWOWOWOWOWOWOWOWOWOWOWOWOWOWOWOWO");


                                        recipeCard.addView(ingT);
                                        recipeCard.addView(instT);
                                        recipeCard.setLayoutParams(expParam);*/

                                    }
                                });
                            }

                        }

                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }else{

            Log.d("myTag", "Empty");

        }



    }
}
