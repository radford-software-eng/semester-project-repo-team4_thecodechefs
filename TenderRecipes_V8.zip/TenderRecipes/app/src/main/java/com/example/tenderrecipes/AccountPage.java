package com.example.tenderrecipes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AccountPage extends AppCompatActivity {

    TextView userT;
    ImageView upArrow;
    LinearLayout recipeListLayout;
    ScrollView recipeScroll;

    AlertDialog dialog;
    AlertDialog.Builder builder;

    int counter = 0;
    int lastItem;

    String menuOption;

    FirebaseDatabase database;
    DatabaseReference recipeDataRef;
    DatabaseReference accountDataRef;
    Query lastQuery;
    ValueEventListener listener;

    ArrayList<Integer> savedRecipes;
    Spinner sortMenu;

    Intent detailIntent;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_page);

        userT = findViewById(R.id.usernameT);
        recipeListLayout = findViewById(R.id.recipeList);
        recipeScroll = findViewById(R.id.recipeScroll);
        upArrow = findViewById(R.id.upArrow);
        sortMenu = findViewById(R.id.sortMenu);

        database = FirebaseDatabase.getInstance();
        recipeDataRef = database.getReference("Recipes");
        //accountDataRef = database.getReference("Accounts");

        detailIntent = new Intent(AccountPage.this, RecipeDetail.class);

        Intent intent = getIntent();
        final Account account = intent.getParcelableExtra("account");

        savedRecipes = intent.getIntegerArrayListExtra("accList");
        for(int i = 0; i < savedRecipes.size();i++){
            Log.d("listt",""+savedRecipes.get(i));
        }

        accountDataRef = database.getReference("Accounts").child(""+account.getId()).child("savedRecipes");
        lastQuery = accountDataRef.orderByKey().limitToLast(1);
        getLastInList();

        /*Query lastQuery = accountDataRef.orderByKey().limitToLast(1);
        lastQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String[] split = dataSnapshot.getValue().toString().replaceAll("[^0-9=]","").split("=");
                addPlHold = Integer.parseInt(split[0]);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/

        userT.setText("Welcome "+account.getUsername());

        String[] sortMenuOptions = new String[]{"All","Breakfast","Lunch","Dinner"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, sortMenuOptions);
        sortMenu.setAdapter(adapter);

        sortMenu.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                recipeListLayout.removeAllViews();
                menuOption = (String)parent.getItemAtPosition(position);
                loadRecipes();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        upArrow.setOnTouchListener(new OnSwipeTouchListener(AccountPage.this){
            public void onSwipeTop() {
                Toast.makeText(getApplicationContext(), "Swipe up", Toast.LENGTH_SHORT).show();
                finish();
            }

        });

        if(!savedRecipes.isEmpty()){

            loadRecipes();

        }else{

            Log.d("myTag", "Empty");

        }



    }

    public void loadRecipes(){
        recipeDataRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(int i = 0; i < savedRecipes.size(); i++){
                    for(DataSnapshot recipeSnapshot : dataSnapshot.getChildren()){
                        final Recipe re = recipeSnapshot.getValue(Recipe.class);
                        Log.d("myTag3", ""+re.getMealTime());
                        if((re.getTempC() == savedRecipes.get(i) && re.getMealTime().equals(menuOption))
                                || (re.getTempC() == savedRecipes.get(i) && menuOption == "All")){
                            drawRecipeCard(re);
                        }

                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.no_animation, R.anim.slide_up);
    }

    @SuppressLint("ClickableViewAccessibility")
    public void drawRecipeCard(final Recipe re){

        final CardView recipeCard = new CardView(getApplicationContext());
        final TextView nameText = new TextView(getApplicationContext());
        final TextView diff = new TextView(getApplicationContext());
        final ImageView img = new ImageView(getApplicationContext());

        nameText.setText(re.getName());
        nameText.setPadding(0,90,0,0);
        nameText.setTypeface(null, Typeface.BOLD);
        nameText.setTextColor(Color.BLACK);

        img.setImageResource(AccountPage.this.getResources().getIdentifier(re.getImgName(),
                "drawable", AccountPage.this.getPackageName()));
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);

        recipeCard.addView(img);
        recipeCard.addView(nameText);
        recipeCard.addView(diff);
        recipeCard.setClickable(true);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 150);
        LinearLayout.LayoutParams spacePar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 20);
        recipeCard.setLayoutParams(params);
        final Space space = new Space(getApplicationContext());
        space.setLayoutParams(spacePar);

        recipeListLayout.addView(recipeCard);
        recipeListLayout.addView(space);


        recipeCard.setOnTouchListener(new OnSwipeTouchListener(AccountPage.this){
            public void onSwipeBottom(){
                detailIntent.putExtra("recipeNum", re.getTempC());
                startActivity(detailIntent);
            }
            public void onSwipeRight(){
                builder = new AlertDialog.Builder(AccountPage.this);
                builder.setTitle("Favorite this recipe?");
                builder.setPositiveButton("Favorite", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(AccountPage.this, "Favorited", Toast.LENGTH_LONG).show();
                    }
                });

                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                dialog = builder.create();
                dialog.show();
            }
            public void onSwipeLeft() {

                builder = new AlertDialog.Builder(AccountPage.this);
                builder.setTitle("Delete this recipe?");
                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        recipeListLayout.removeView(recipeCard);
                        recipeListLayout.removeView(space);
                        for (int i = 0; i < savedRecipes.size(); i++) {
                            if (savedRecipes.get(i) == re.getTempC()) {
                                savedRecipes.remove(i);
                                Log.d("helloo",""+savedRecipes.size());
                            }
                        }

                        accountDataRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                boolean start = false;
                                counter = 0;
                                for (DataSnapshot accountSnapshot : dataSnapshot.getChildren()) {

                                    int temp = Integer.parseInt(accountSnapshot.getValue().toString());

                                    if (re.getTempC() == temp) {
                                        start = true;
                                    }

                                    if (start && re.getTempC() != temp) {
                                        accountDataRef.child("" + (counter - 1)).setValue(temp);
                                    }

                                    counter++;

                                    //getLastInList();

                                    if (counter == lastItem){
                                        removeLast();
                                    }

                                }


                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                    }
                }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                dialog = builder.create();
                dialog.show();

            }



        });


    }

    public void getLastInList(){
        lastQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String[] split = dataSnapshot.getValue().toString().replaceAll("[^0-9=]","").split("=");
                lastItem = (Integer.parseInt(split[0]));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void removeLast(){

        accountDataRef.child("" + (savedRecipes.size())).removeValue();
        accountDataRef.getParent().child("listSize").setValue(savedRecipes.size());

    }

}
