package com.example.tenderrecipes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Registration extends AppCompatActivity {

    Button registration;
    EditText userField;
    EditText passField;

    ArrayList<Account> accounts = new ArrayList<>();

    FirebaseDatabase database;
    DatabaseReference dataRef;

    Intent logInt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        registration = findViewById(R.id.regButton);
        userField = findViewById(R.id.usernameField);
        passField = findViewById(R.id.passwordField);

        database = FirebaseDatabase.getInstance();
        dataRef = database.getReference("Accounts");

        logInt = new Intent(Registration.this, MainActivity.class);

        dataRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot accountSnapshot : dataSnapshot.getChildren()){

                    Account acc = accountSnapshot.getValue(Account.class);
                    accounts.add(acc);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n = (accounts.get(accounts.size()-1).getId() + 1);
                String newUser = userField.getText().toString();
                String newPass = passField.getText().toString();
                if(!newUser.equals("") && !newPass.equals("")){
                    boolean userAvailable = true;
                    for(int i = 0; i < accounts.size(); i++){
                        if(accounts.get(i).getUsername().equals(newUser)){
                            userAvailable = false;
                        }
                    }
                    if(userAvailable){
                        Toast.makeText(Registration.this, "Account Created!", Toast.LENGTH_LONG).show();
                        Account temp = new Account(newUser,newPass,false,n);
                        dataRef.child(""+n).setValue(temp);
                        logInt.putExtra("accRef", n);
                        startActivity(logInt);

                    }else {
                        Toast.makeText(Registration.this, "Username Unavailable!", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(Registration.this, "You must enter a Username and Password.", Toast.LENGTH_LONG).show();
                }

                //startActivity(new Intent(Registration.this, LogIn.class));
            }
        });

    }
}
