package com.example.tenderrecipes;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registration extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button submit;

    FirebaseDatabase database;
    DatabaseReference AccountDBRef;

    Intent detailIntent;
    Account currentAccount;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);

        username = findViewById(R.id.userField);
        password = findViewById(R.id.pwField);
        submit = findViewById(R.id.submitButton);

        detailIntent = new Intent(Registration.this, Account.class);

        database = FirebaseDatabase.getInstance();
        AccountDBRef = database.getReference("Accounts");

        Intent logInt = getIntent();
        Bundle extras = logInt.getExtras();






        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "You Clicked Submit", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
