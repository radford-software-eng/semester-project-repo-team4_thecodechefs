package com.example.databasetest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button send, retrieve;
    String name = "testName";
    int age = 100;
    int id = 100;

    TextView nameT,ageT;

    DatabaseReference databaseReference;

    ArrayList<Student> students = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        send = findViewById(R.id.sendB);
        retrieve = findViewById(R.id.retrieveB);
        nameT = findViewById(R.id.nameT);
        ageT = findViewById(R.id.ageT);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("Students");

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addStudent();
                id = id+1;
            }
        });

        retrieve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retrieveStudents();
            }
        });

    }

    public void retrieveStudents(){

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot studentSnapshot : dataSnapshot.getChildren()){

                    Student stud = studentSnapshot.getValue(Student.class);
                    students.add(stud);
                }
                //studentInfoLoad studentInfoLoad = new studentInfoLoad(MainActivity.this, students);
                StringBuilder temp = new StringBuilder();
                for(int i = 0; i < students.size(); i++){

                    temp.append(students.get(i).getId());
                    if(students.get(i).getId() == 101){

                        nameT.setText(""+students.get(i).getName());
                        ageT.setText(""+students.get(i).getAge());

                    }

                }
                students.clear();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void addStudent(){

        //String id = databaseReference.push().getKey();

        Student student = new Student(name, age, id);
        //this.id = id++;
        databaseReference.child(""+id).setValue(student);


    }
}
