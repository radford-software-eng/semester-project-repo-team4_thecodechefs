package com.example.databasetest;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class studentInfoLoad extends ArrayAdapter<Student> {

    private Activity context;
    private List<Student> studentList;

    public studentInfoLoad(@NonNull Activity context, List<Student> studentList) {
        super(context, R.layout.list_view, studentList);
        this.context = context;
        this.studentList = studentList;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();
        View listView = inflater.inflate(R.layout.list_view,null,true);

        TextView studName = listView.findViewById(R.id.name);
        TextView studAge = listView.findViewById(R.id.age);

        Student student = studentList.get(position);
        studName.setText(student.getName());
        studAge.setText(student.getAge());

        return listView;
    }
}
