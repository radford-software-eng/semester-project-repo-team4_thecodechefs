package com.example.tenderrecipes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class AccountPage extends AppCompatActivity {

    TextView userT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_page);

        userT = findViewById(R.id.usernameT);

        Intent i = getIntent();

        Account account = i.getParcelableExtra("account");

        Toast.makeText(AccountPage.this, account.getUsername(), Toast.LENGTH_SHORT).show();

        userT.setText("Welcome "+account.getUsername());


    }
}
