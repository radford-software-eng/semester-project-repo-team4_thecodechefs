package com.example.tenderrecipes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements
        GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener{

    int counter = 0;
    Context mContext;

    TextView nameT;
    TextView timeT;
    TextView ingrT;

    ImageView recImg;

    Button nextButton;
    Button saveButton;
    Button accountButton;

    FirebaseDatabase database;
    DatabaseReference recipeDataRef;

    ArrayList<Recipe> recipes = new ArrayList<>();

    Account currAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Gets the database
        database = FirebaseDatabase.getInstance();
        //References the Recipes section
        recipeDataRef = database.getReference("Recipes");

        Intent logInt = getIntent();
        Bundle extras = logInt.getExtras();
        currAccount = new Account(extras.getString("accName"), extras.getString("accPass"));

        recImg = findViewById(R.id.recipeImg);

        nameT = findViewById(R.id.nameText);
        timeT = findViewById(R.id.timeText);
        ingrT = findViewById(R.id.ingredientsText);

        nextButton = findViewById(R.id.nextButton);
        saveButton = findViewById(R.id.saveB);
        accountButton = findViewById(R.id.accountB);
        //Button instButton = findViewById(R.id.instButton);

        //Check this method Chris
        addRecipes();

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Random randInt = new Random();
                int randCount = counter;
                while(randCount == counter){
                    counter = randInt.nextInt(recipes.size());
                }

                setCurrentRecipe(recipes, nameT, timeT, ingrT, counter);
                Log.d("mytag", "" + counter);

                recImg.setImageResource(MainActivity.this.getResources().getIdentifier(recipes.get(counter).getImgName(),
                        "drawable", MainActivity.this.getPackageName()));

            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save(currAccount, recipes.get(counter));
            }
        });

        accountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accountPage(currAccount);
            }
        });



        /*instButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainActivity.this, Instructions.class));

            }
        });*/

    }

    public void save(Account currAccount, Recipe r){

        if(!currAccount.contains(r)) {
            currAccount.addRecipe(r);
        }else{
            Toast.makeText(MainActivity.this, "This recipe is already saved", Toast.LENGTH_SHORT).show();
        }


    }

    public void accountPage(Account current){

        Intent i = new Intent(MainActivity.this, AccountPage.class);
        i.putExtra("account", current);
        startActivity(i);

    }

    public void setCurrentRecipe(ArrayList<Recipe> recipes, TextView nameT, TextView timeT, TextView ingrT, int counter){

        Recipe currRec = recipes.get(counter);
        nameT.setText(currRec.getName());
        timeT.setText("Time: " + currRec.getTime());
        String ing = currRec.getIngredients().replace("_n","\n");
        ingrT.setText("Ingredients: \n" + ing);

    }


    public void addRecipes(){

        //To get data from the database add a ValueEventListener, adding it will
        //automatically create the onDataChange and onCancelled methods
        recipeDataRef.addValueEventListener(new ValueEventListener() {
            @Override
            //Use this to read in the recipes(or accounts for you)
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot recipeSnapshot : dataSnapshot.getChildren()){

                    Recipe re = recipeSnapshot.getValue(Recipe.class);
                    recipes.add(re);

                }

                //You shouldn't need anything like this, i'm just setting the default recipe that is displayed
                setCurrentRecipe(recipes, nameT, timeT, ingrT, 0);
                recImg.setImageResource(MainActivity.this.getResources().getIdentifier(recipes.get(counter).getImgName(),
                        "drawable", MainActivity.this.getPackageName()));
                Log.d("myTag", ""+counter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        Log.d("gestTag", "onDoubleTap: " + e.toString());
        final TextView nameT = findViewById(R.id.nameText);
        nameT.setText("Tapped");
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        Log.d("gestTag","onDown: " + e.toString());
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }
}
